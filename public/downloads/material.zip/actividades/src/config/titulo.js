module.exports = 'Marco normativo sobre GEI y metodologías de cálculo de GEI.'
