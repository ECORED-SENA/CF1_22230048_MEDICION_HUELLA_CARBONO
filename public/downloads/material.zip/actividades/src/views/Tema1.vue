<template lang="pug">
.curso-main-container.pb-3
  BannerInterno
  .container.tarjeta.tarjeta--blanca.p-4.p-md-5
    .titulo-principal.color-acento-contenido(data-aos="fade-up")
      .titulo-principal__numero
        span.text-white 1
      h1 Marco normativo internacional sobre GEI
    p(data-aos="fade-up-right") El marco normativo internacional sobre el cambio climático tiene una historia amplia, rica y, sobre todo, un proceso de evolución significativo, el cual ha permitido integrar conceptos como desarrollo sostenible, evidenciar contribuciones nacionalmente determinadas y desarrollar marcos de acción para controlar y mitigar el calentamiento global. 
    p.mb-5(data-aos="fade-up-right") Revise con atención el siguiente recurso educativo en el que se presentan cada uno de los hitos normativos y marcos de referencia asociados a los GEI:

    .row.justify-content-center
      .col-xxl-12.fondo1
        .tarjeta.p-4.mb-5(data-aos="fade-up-right")
           LineaTiempoC.color-acento-contenido(text-small)
            .row(titulo="1972")
              .col-md-4.ps-5
                figure
                  img.sizeimg(src='@/assets/curso/tema1/tiempo1.png')
                p.text-small.text-end Nota: tomado de timetoast.org
              .col-md-8.mb-4.mb-md-0
                p Durante este año, se crea la Conferencia de las Naciones Unidas sobre Medio Ambiente Humano y se conforma el PNUMA - Programa de las Naciones Unidas para el Medio Ambiente.<br/> 
                  span Los países participantes adoptaron una serie de principios establecidos en  la Declaración de Estocolmo para  la gestión racional de los recursos naturales y la preservación del medio ambiente.<br/>
                  span Dichos principios  lo que buscaban era posicionar los aspectos medio ambientales en el primer plano en las agendas de diálogo entre los países desarrollados, tratando temas como la relación del medio ambiente con el crecimiento económico, la contaminación de las fuentes hídricas, la calidad del aire y el bienestar ambiental en todo el mundo.

            .row(titulo="1987")
              .col-md-4.ps-5
                figure
                  img.sizeimg(src='@/assets/curso/tema1/tiempo2.png')
                p.text-small.text-end Nota: tomado de www.americansecurityproject.org
              .col-md-8.mb-4.mb-md-0
                p Durante este año, se creó el Protocolo de Montreal y la Convención de Viena, los cuales tienen como objetivo regular y paulatinamente transitar hacia la eliminación de las Sustancias Agotadoras de la Capa de Ozono (SAO). Los países en este marco de referencia adquieren la obligación de cumplir procesos y calendarios de sustitución y eliminación de SAO, y deben prohibir el comercio de estas sustancias con los países que no han ratificado dicho protocolo.
            
            .row(titulo="1988")
              .col-md-4.ps-5
                figure
                  img.sizeimg(src='@/assets/curso/tema1/tiempo3.png')
                p.text-small.text-end Nota: tomado de www.retema.es
              .col-md-8.mb-4.mb-md-0
                p Durante este año, se crea  el Grupo Intergubernamental de Expertos sobre el Cambio Climático (IPCC), con el objetivo de facilitar la evaluación integral de los conceptos y conocimientos socioeconómicos, técnicos y científicos relacionados con el cambio climático, las causas, repercusiones y gestión climática, esto con el fin de estar preparados para atender los desafíos globales.

            .row(titulo="1990")
              .col-md-4.ps-5
                figure
                  img.sizeimg(src='@/assets/curso/tema1/tiempo4.png')

              .col-md-8.mb-4.mb-md-0
                p Durante este año, se desarrolla el <i>First Assessment Report</i> IPCC (FAR), que es el primer informe de evaluación del Panel Intergubernamental de Expertos sobre el Cambio Climático (IPCC).<br/>
                  span Este reporte sirve como fundamento para el desarrollo de la Convención Marco de las Naciones Unidas sobre el Cambio Climático (CMNUCC), dicho informe fue  un referente para la definición de la primera Conferencia de las Partes (COP) sobre el Clima, desarrollada posteriormente, en 1995, en Berlín, Alemania.

            .row(titulo="1992")
              .col-md-4.ps-5
                figure
                  img.sizeimg(src='@/assets/curso/tema1/tiempo5.png')
                p.text-small.text-end Nota: tomado de www.terra.org
              .col-md-8.mb-4.mb-md-0
                p Durante este año, se desarrolla la Convención Marco de las Naciones Unidas sobre el Cambio Climático (CMNUCC) o mejor conocida como la Convención de Río 92 o Cumbre de la Tierra. En esta convención, la comunidad internacional tenía el desafío de abordar el modelo de desarrollo global, de modo tal que se establecieron los lineamientos necesarios para garantizar conjuntamente el bienestar social, el desarrollo económico y la preservación de los recursos naturales y el medio ambiente.
                p  En este foro, se estableció que la sostenibilidad era la única estrategia para asegurar un desarrollo ambientalmente viable para las generaciones actuales y futuras.

            .row(titulo="1997")
              .col-md-4.ps-5
                figure
                  img.sizeimg(src='@/assets/curso/tema1/tiempo6.png')
                p.text-small.text-end Nota: tomado de www.britannica.com
              .col-md-8.mb-4.mb-md-0
                p Fue adoptado el Protocolo de Kyoto, sin embargo, dado lo complejo que fue su proceso de ratificación, solo entró en vigor a comienzos del año 2005. En el marco de este protocolo, los países industrializados adquieren el compromiso de tomar acciones para reducir las emisiones de Gases Efecto Invernadero (GEI). Los países que firmaron y ratificaron dicho protocolo se comprometieron a reducir en al menos un 5% sus emisiones y a lograrlo entre los años 2008 y 2012, considerando como año base los niveles de emisiones generados en el año de 1990.

            .row(titulo="2012")
              .col-md-4.ps-5
                figure
                  img.sizeimg(src='@/assets/curso/tema1/tiempo7.png')
                p.text-small.text-end Nota: tomado de www.diversidadambiental.org
              .col-md-8.mb-4.mb-md-0
                p En el año 2012, en la ciudad de Doha, los países miembros de las Naciones Unidas aprobaron lo que se denomina la enmienda de Doha al Protocolo de Kyoto para un segundo periodo de compromiso, el cual tuvo como año de inicio el 2013, teniendo una duración de 8 años.

            .row(titulo="2015")
              .col-lg-4.col-md-5.mb-4.mb-md-0.ps-md-5
                figure
                  img(src='@/assets/curso/tema1/tiempo8.png')
                p.text-small.text-end Nota: tomado de www.tiempo.com
              .col-lg-8.col-md-7.mb-4.mb-md-0
                p Se desarrolla la COP 21 - Acuerdo de París, el cual es el tratado internacional jurídicamente vinculante sobre cambio climático. Su objetivo es controlar y reducir el calentamiento global por debajo de los 2 grados centígrados.
                p Para lograr esta ambición global, los países firmantes del acuerdo deben alcanzar unas emisiones máximas de GEI, logrando una neutralización del clima global para mediados del siglo XXI.
                p Con el acuerdo de aplicación de las directrices definidas en el Acuerdo de París, año a año se celebra una CO con el objetivo principal de validar pendientes para la puesta en marcha del total de acuerdos, metas y acciones definidas por los países firmantes.


</template>

<script>
import BannerInterno from '../components/BannerInterno.vue'
export default {
  name: 'Tema1',
  components: {},
  data: () => ({
    // variables de vue
  }),
  mounted() {
    this.$nextTick(() => {
      this.$aosRefresh()
    })
  },
  updated() {
    this.$aosRefresh()
  },
}
</script>

<style lang="sass"></style>
