<template lang="pug">
.curso-main-container.pb-3
  BannerInterno
  .container.tarjeta.tarjeta--blanca.p-4.p-md-5    
    .titulo-principal.color-acento-contenido(data-aos="fade-up-right")
      .titulo-principal__numero
        span.text-white 3
      h1 Portafolio de políticas públicas de adaptación y mitigación del cambio climático por sectores de la economía
    .row.justify-content-center.align-items-center
      .col-xxl-6.col-xl-6.col-lg-6.col-md-11.col-sm-11.col-11.mb-5(data-aos="fade-up-right")
        p Los instrumentos de planificación permiten el cumplimiento de las metas y objetivos trazados y propician el establecimiento de actividades concretas del gobierno y de cada uno de los sectores de la economía responsables de la correspondiente implementación. Por ello, el diseñar e implementar instrumentos de planificación asegura el cumplimiento de las metas y objetivos propuestos por el gobierno en instancias internacionales.
        p La política nacional de cambio climático es la base sobre la cual se establecen los diferentes instrumentos y políticas públicas que permiten la adaptación y mitigación del cambio climático. 
        p En la figura 1, se muestran las líneas instrumentales de esta política
      .col-xxl-6.col-xl-6.col-lg-6.col-md-11.col-sm-11.col-11.mb-5(data-aos="fade-up-left")
        img(src='@/assets/curso/tema3/imagen1.png')
    .row.justify-content-center.mt-5
      .col-xxl-12(data-aos="fade-up-right")
        .row.justify-content-center
          .col-xxl-10.col-xl-10.col-lg-10.col-md-11.col-sm-11.col-11
            .titulo-sexto.color-acento-contenido.encima 
              h5 Figura 1. 
              span Líneas instrumentales política nacional de cambio climático
        img.subir(src='@/assets/curso/tema3/figura1.svg')
    p.my-5 Los instrumentos de la política nacional de cambio climático son el marco de referencia para la definición de planes y estrategias que posibilitan la gestión del cambio climático a nivel territorio y sector de la economía; dentro de esta política, se tienen algunos instrumentos de gestión, para conocerlos, revise a detalle el siguiente recurso educativo:
    .row
      .col-xxl-1.col-xl-1.col-lg-1.col-md-1
      .col-xxl-3.col-xl-3.col-lg-3.col-md-3.fondo4.pt-0.px-0.mb-sm-5.pb-sm-5.pb-md-4.ms-md-4.ms-lg-1(data-aos="fade-up-right")
        img(src='@/assets/curso/tema3/imagen2.png')
        p.mx-4.my-3 La Contribución Nacionalmente Determinada (NDC), actualización quinquenal (según acuerdo de París, esta debe ser actualizada cada 5 años). 
      .col-xxl-2.col-xl-2.col-lg-2.col-md-2
      .col-xxl-3.col-xl-3.col-lg-3.col-md-3.fondo4.pt-0.px-0.pb-4.mb-sm-5.pb-sm-5.pb-md-4(data-aos="fade-up-left")
        img(src='@/assets/curso/tema3/imagen3.png')
        p.m-4 Las estrategias nacionales de cambio climático.
    .row.justify-content-center
      .col-xxl-11.col-xl-11.col-lg-11.col-md-11(data-aos="fade-up-right")
        img.ms-3.nomostrar(src='@/assets/curso/tema3/linea.png')
    .row
      .col-xxl-3.col-xl-3.col-lg-3.col-md-3
      .col-xxl-3.col-xl-3.col-lg-3.col-md-3.fondo5.px-0.pb-0.pt-3.ms-4.mt-sm-5.pt-sm-5.pt-md-4(data-aos="fade-up-right")
        p.mx-4.mt-5 Los planes integrales de gestión del cambio climático territoriales.
        img(src='@/assets/curso/tema3/imagen4.png')
      .col-xxl-2.col-xl-2.col-lg-2.col-md-2
      .col-xxl-3.col-xl-3.col-lg-3.col-md-3.fondo5.px-0.pb-0.pt-3.ms-md-1.ms-lg-4.mt-sm-5.pt-sm-5.pt-md-4(data-aos="fade-up-left")
        p.mx-4.mt-5 Los planes integrales de gestión del cambio climático sectoriales.
        img(src='@/assets/curso/tema3/imagen5.png')
    p.my-5 Por otro lado, en Colombia, se cuenta con una serie de estrategias nacionales frente al cambio climático, las cuales puede conocer a través del siguiente recurso educativo:

    SlyderF.mb-5(data-aos="fade-up")(columnas="col-lg-6 col-xl-4")
      .tarjeta-avatar.sizetarjetaslider
        img.sizeimg1(src='@/assets/curso/tema3/slider1.svg')
        .tarjeta.fondo6
          .px-4.pb-4.pt-2
            p Estrategia Colombia de Desarrollo Bajo en Carbono (ECDBC) 

      .tarjeta-avatar.sizetarjetaslider
        img.sizeimg1(src='@/assets/curso/tema3/slider2.svg')
        .tarjeta.fondo6
          .px-4.pb-4.pt-2
            p Plan Nacional  de Adaptación al Cambio Climático (PNACC)

      .tarjeta-avatar.sizetarjetaslider
        img.sizeimg1(src='@/assets/curso/tema3/slider3.svg')
        .tarjeta.fondo6
          .px-4.pb-4.pt-2
            p Planes integrales  de gestión del cambio climático sectoriales y territoriales

      .tarjeta-avatar.sizetarjetaslider
        img.sizeimg1(src='@/assets/curso/tema3/slider4.svg')
        .tarjeta.fondo6
          .px-4.pb-4.pt-2
            p Estrategia Nacional para la Reducción  de las Emisiones debidas a la Deforestación  y la Degradación forestal. (ENREDD+)

      .tarjeta-avatar.sizetarjetaslider
        img.sizeimg1(src='@/assets/curso/tema3/slider5.svg')
        .tarjeta.fondo6
          .px-4.pb-4.pt-2
            p El Plan Nacional de Riesgo de Desastres

      .tarjeta-avatar.sizetarjetaslider
        img.sizeimg1(src='@/assets/curso/tema3/slider6.svg')
        .tarjeta.fondo6
          .px-4.pb-4.pt-2
            p Estrategia de Protección Financiera frente a Desastres.

      .tarjeta-avatar.sizetarjetaslider
        img.sizeimg1(src='@/assets/curso/tema3/slider7.svg')
        .tarjeta.fondo6
          .px-4.pb-4.pt-2
            p Estrategia Nacional de Financiamiento Climático. 
    p.my-5(data-aos="fade-up-right") En Colombia, se han definido seis (6) sectores prioritarios para el establecimiento de las medidas de adaptación y mitigación del cambio climático, los cuales son: energético, transporte, agropecuario, industrial, residuos y forestal, y para cada uno de estos sectores, se han definido algunas medidas que podrá conocer a través del siguiente recurso educativo:
    figure.mb-5(data-aos="fade")
      .video
        iframe(width="560" height="315" src="https://www.youtube.com/embed/fIhnxWwxkg4" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen)
      figcaption Video: Leyenda del video    
</template>

<script>
import BannerInterno from '../components/BannerInterno.vue'
export default {
  name: 'Tema3',
  data: () => ({
    // variables de vue
  }),
  mounted() {
    this.$nextTick(() => {
      this.$aosRefresh()
    })
  },
  updated() {
    this.$aosRefresh()
  },
}
</script>

<style lang="sass"></style>
